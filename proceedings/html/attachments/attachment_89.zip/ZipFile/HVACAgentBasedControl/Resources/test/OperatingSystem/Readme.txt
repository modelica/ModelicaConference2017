Tests for the ../src/OperatingSystem module
