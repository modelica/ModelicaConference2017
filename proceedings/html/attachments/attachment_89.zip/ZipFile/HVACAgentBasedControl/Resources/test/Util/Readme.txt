Utility classes used across the tests

