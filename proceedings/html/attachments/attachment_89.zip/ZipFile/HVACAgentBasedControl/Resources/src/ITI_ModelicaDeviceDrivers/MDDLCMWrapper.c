/** Wrapping header-only library MDDLCM.h into a DLL.
 *
 * @file
 * @author		tbeu
 * @since		2016-05-05
 *
 *
*/
#include "../../Include/MDDLCM.h"
