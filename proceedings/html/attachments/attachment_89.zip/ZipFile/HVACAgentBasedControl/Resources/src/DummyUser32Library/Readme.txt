Dummy library for Linux.
