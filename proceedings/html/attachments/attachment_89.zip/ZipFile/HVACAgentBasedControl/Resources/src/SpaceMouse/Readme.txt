* 3Dconnexion Space Mouse support for Windows and Linux *


* Microsoft Windows

MS Windows space mouse support is realized using the Windows Driver Kit 7.1.0 (WDK 7.1.0)
(see "Modelica_DeviceDrivers/Resources/thirdParty/hdisdi").


* Linux

Linux space mouse support requires the *3Dconnexion Software Developer Kit* for linux
(see "Modelica_DeviceDrivers/Resources/thirdParty/3DconnexionSDK").

Note that additional to this library it is still necessary to install the linux drivers for the space mouse (also available from http://www.3dconnexion.com/) to use the Modelica space mouse block.
