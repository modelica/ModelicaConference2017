/** Wrapping header-only library MDDSoftingCAN.h into a DLL.
 *
 * @file
 * @author		bernhard-thiele
 * @since		2014-04-12
 *
 *
*/
#define MDDSOFTINGCANUSECMAKE
#include "../../Include/MDDSoftingCAN.h"
