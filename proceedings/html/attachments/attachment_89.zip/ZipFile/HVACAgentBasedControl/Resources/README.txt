The folders Include, Library, src and test were copied from the Modelica_DeviceDrivers library v1.4.4. 
This was neccessary in order to make UDP communication work with the adapted communication models in
the HVACAgentBasedControl library.