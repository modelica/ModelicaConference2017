############################INFORMATION###################################

This folder contains the Modelica HVACAgentBasedControl library v1.0.0.

The Modelica HVACAgendBasedControl presents a set of agents which can 
control building energy systems and systems of similar characteristics 
(e.g. district heating networks or electrical smart-grids). It depcits 
a plug&play solution to control systems with multiple energy suppliers. 
With the help of a market-based communication mechanism and cost 
functions for each heat supplier, the most cost effective energy 
supplier in the system is always chosen. With the help of individual 
cost functions the "costs" that should be minimized can be defined
individually by the developer (e.g. money, primary energy, exergy 
destruction). 

###########################REQUIREMENTS###################################

The library uses the following open source Modelica libraries:
- Modelica_DeviceDrivers v1.4.4 (https://github.com/modelica/Modelica_DeviceDrivers)
- AixLib v0.3.2 (https://github.com/RWTH-EBC/AixLib), which is only necessary to run the models in the "Example" package 

In order to avoid version collisions please open the above named libraries 
BEFORE opening the HVACAgentBasedControl library.


###########################GETTING STARTED################################

In order to get started on using the agents provided by this library please
refer to the "Getting started" file of the "User's Guide" package inside 
the Modelica library.

################################CONTACT###################################

Roozbeh Sangi (rsangi@eonerc.rwth-aachen.de)
Felix B�nning (fbuenning@eonerc.rwth-aachen.de)
 
RWTH Aachen University 
E.ON Energy Research Center
Institute for Energy Efficient Buildings and Indoor Climate  
Mathieustra�e 10 
52074 Aachen
Germany 
www.eonerc.rwth-aachen.de/ebc 



